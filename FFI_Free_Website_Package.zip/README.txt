FINE FIBER INSPECTION — FREE WEBSITE STARTER

Included:
- index.html: responsive one-page website with basic SEO metadata and structured business data.
- No paid theme or software required.

Before publishing:
1. Replace YOUR-DOMAIN-OR-FREE-SUBDOMAIN in the canonical link and JSON-LD URL with the final website URL.
2. Confirm the business address, phone, email, service descriptions and all claims.
3. Add genuine original FFI photos and a privacy notice if you add an enquiry form or analytics.
4. Create/verify the Google Business Profile separately. A website does not automatically create or verify a Google listing.

Free publishing option:
- GitHub Pages can host a static website free on a github.io subdomain for eligible public repositories.
- Create a GitHub account, create a public repository named <username>.github.io, upload index.html, then enable Pages if needed.
- Your site will be available at https://<username>.github.io/
- A custom .com domain is optional and normally costs money.

Important:
This package is a ready-to-publish website source, not a live hosted website. No Google account credentials are needed or included.
